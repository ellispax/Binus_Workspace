import csv
import json
import atexit
import matplotlib.pyplot as plt
import pathlib
import getpass
import datetime
from datetime import date
from time import strftime 


class Climate_Buddy:
    def __init__(self):
        self.username1 = ""
        self.start1 = ""
    
    def login(self, start):
        
        print("""\n
                    *******************************************
                        Welcome To The Climate Buddy v1.01 
                    *******************************************
                        Please use your credentials to login
                    -------------------------------------------""")
        status = False
        while status ==False:
            username = input("USERNAME >> _ _ ")
            password  = getpass.getpass()

            if username in start.users and (start.getUser(username).getpass()) == password:
                print("welcome user >> ", username)
                status = True
                self.username1 = username
                return username
                

            else:
                print("Invalid Login Credentials !!\nIf you dont have login credentials contact system adminstrator.")

    def loadjson(self): #this block of code is used load the json file that has user data
        filename = "/Users/ellispaxmapakama/Desktop/workspace/final project/climate.json"
        with open(filename, "r") as f:
            fill = json.load(f)
            get = Climate(fill["System"]) # get is an instance of Climate class initialized with dict System

            for key, value in fill["users"].items():# users is a key of dict in fill
                make = Users(value["fname"], value["password"], value["access"]) # make is an instance of Users class, 
                make.set_access(value["access"])
                
                get.create_user(key, make) #make has user data ready to be saved under key i.e username
                
            
            return get

    def savejson(self, start): #this block of code is used to save user data to the json file
        filename = "/Users/ellispaxmapakama/Desktop/workspace/final project/climate.json"  
        with open(filename,"w") as fp:
            fil = {}
            fil["System"] = start.System #start is a variable containing result from loadjson which is object of Climate,
                                         #start.System returns Climate Buddy
            fil["users"] = {}
            for username, data in start.getall().items():#this copies all the data from user in Climate class into users
                fil["users"][username] = {
                    "fname": data.getuser(),
                    "password": data.getpass(),
                    "access": data.getAccess()
                }
            json.dump(fil, fp, indent = 4)

    def get_filepath(self):
        root = "/Users/ellispaxmapakama/Desktop/workspace/final project/csv/" #this scpecifies the path where the csv files are saved
        name = str(input("Enter complete filename with extension >> ")) #user inputs filename in specified folder includin file extension
        Filename = pathlib.Path(root + name) #strin concatination to create the complete file path

        if Filename.exists(): #check if the created file path is valid or not
            return Filename
        else:
            print("The file that you are trying to mount does not exist!")
            self.main_menu(self.start1,self.username1)
    def extract(self): # this function returns lists containing raw values from csv file
        print("Choose CSV file that you want to Extract Data from.")
        filename = self.get_filepath()

        #intializing lists that will store values extracted from the csv file
        date = []
        min_temps, max_temps, avg_temps = [],[],[]
        max_humidity, min_humidity, avg_humidity, cloud_cover = [],[],[],[]
        max_windspeed, min_windspeed, avg_windspeed, wind_gust = [],[],[],[]
        max_pressure, min_pressure, avg_pressure = [],[],[]
        visibility, sun_hours = [],[]
        precipitation = []


        with open(filename) as f:
            reader = csv.reader(f)
            header_row = next(reader)
            for row in reader: #appending values from each column to the designate list
                date.append(row[0])
                max_temps.append(float(row[1]))
                min_temps.append(float(row[2]))
                avg_temps.append(float(row[3]))

                max_humidity.append(float(row[4]))
                min_humidity.append(float(row[5]))
                avg_humidity.append(float(row[6]))
                cloud_cover.append(float(row[7]))
        
                max_windspeed.append(float(row[8]))
                min_windspeed.append(float(row[9]))
                avg_windspeed.append(float(row[10]))
                wind_gust.append(float(row[11]))

                max_pressure.append(float(row[12]))
                min_pressure.append(float(row[13]))
                avg_pressure.append(float(row[14]))

                visibility.append(float(row[15]))
                sun_hours.append(float(row[16]))
                precipitation.append(float(row[17]))

        return date, max_temps, min_temps, avg_temps, max_humidity, min_humidity, avg_humidity, cloud_cover, max_windspeed, min_windspeed, avg_windspeed, wind_gust, max_pressure, min_pressure, avg_pressure, visibility, sun_hours, precipitation
            
    def calc_annual_avgs(self, x):
        # variables will get values returned by the extract()
        date, max_temps, min_temps, avg_temps, max_humidity, min_humidity, avg_humidity, cloud_cover, max_windspeed, min_windspeed, avg_windspeed, wind_gust, max_pressure, min_pressure, avg_pressure, visibility, sun_hours, precipitation = x

        day_counter = 0
        
        for item in date: # this will count the number of dates in the csv
            day_counter += 1
        
        day = int(day_counter) # changing day to tpye int
        
        #intializing variables that will contain calculated averages
        maxtemp, mintemp, avgtemp = 0,0,0
        maxhumidity, minhumidity, avghumidity, cloudcover  = 0,0,0,0
        maxwindspeed, minwindspeed, avgwindspeed,windgust = 0,0,0,0
        maxpressure, minpressure, avgpressure = 0,0,0
        visibility_, sunhours = 0,0
        precp = 0
        
        #calculating averages using the sum function since data is in list form
        maxtemp = (sum(max_temps))/day
        mintemp = (sum(min_temps))/day
        avgtemp = (sum(avg_temps))/day
        maxhumidity = (sum(max_humidity))/day
        minhumidity = (sum(min_humidity))/day
        avghumidity = (sum(avg_humidity))/day
        cloudcover = (sum(cloud_cover))/day
        maxwindspeed = (sum(max_windspeed))/day
        minwindspeed = (sum(min_windspeed))/day
        avgwindspeed = (sum(avg_windspeed))/day
        windgust = (sum(wind_gust))/day
        maxpressure = (sum(max_pressure))/day
        minpressure = (sum(min_pressure))/day
        avgpressure = (sum(avg_pressure))/day
        visibility_ = (sum(visibility))/day
        sunhours = (sum(sun_hours))
        precp = (sum(precipitation))/day

        return maxtemp,mintemp,avgtemp,maxhumidity,minhumidity,avghumidity,cloudcover,maxwindspeed,minwindspeed,avgwindspeed,windgust,maxpressure,minpressure,avgpressure,visibility_,sunhours,precp

    def writecsv(self):
        aa,ab,ac,ad,ae,af,ag,ah,ai,aj,ak,al,am,an,ao,ap,aq = self.calc_annual_avgs(self.extract()) #variables used to get values returned by cal_annual_avgs()
        ans = input("Are you about to Save Monthly or Yearly Averages?\nMonthly (M) or Yearly (Y) >> ")

        print("Choose CSV file you want to save data to.")
        filename = self.get_filepath()# called to get file path for the csv file needed for saving averages

        if ans.upper() == "M":
            date = input("Enter Month >> ")
        else:
            date = input("Enter Year >> ")

        #row is a list containing averageges to be appended into the new csv
        row = [str(date),str(round(aa, 2)),str(round(ab, 2)),str(round(ac, 2)),str(round(ad, 2)),str(round(ae, 2)),str(round(af, 2)),str(round(ag, 2)),str(round(ah, 2)),str(round(ai,2)),str(round(aj,2)),str(round(ak, 2)),str(round(al, 2)),str(round(am,2)),str(round(an,2)),str(round(ao, 2)),str(round(ap, 2)),str(round(aq, 2))]

        
        with open(filename, 'a') as csvFile: # opening the csv file with append so that you dont overwrite the file when saving
            writer = csv.writer(csvFile)
            writer.writerow(row) # appending row which has the averages
            print(f"Data Has been saved in the designated CSV file.")
        csvFile.close()         
        self.main_menu(self.start1,self.username1)

    def plot_day(self, x):

        date, max_temps, min_temps, avg_temps, max_humidity, min_humidity, avg_humidity, cloud_cover, max_windspeed, min_windspeed, avg_windspeed, wind_gust, max_pressure, min_pressure, avg_pressure, visibility, sun_hours, precipitation = x
        
        month = input("Enter name of month you will be working on >> ")
        yr = input("Enter year >> ")

       
        dates = range(1, len(date + ['1']), 1) # creates xticks


        fig, axs = plt.subplots(3, 2,sharex= 'col')
        plt.setp(axs, xticks = dates, xticklabels = date)
        
        fig.suptitle(f'Weather Trends for {month} {yr} ')

        #axs[0, 0] will be the axis were the graph showing pressure trends
        axs[0, 0].plot(dates, max_pressure, label = "Max ")
        axs[0, 0].plot(dates, min_pressure, label = "Min ")
        axs[0, 0].plot(dates, avg_pressure, label = "Avg")
        axs[0, 0].set(ylabel = "Pressure (Hg)")
        axs[0, 0].set_title('Min, Max, Average Pressure')
        axs[0, 0].legend()
        
        #axs[0, 1] will show trends for Windspeed and Wind Gust
        axs[0, 1].plot(dates, max_windspeed,label = "Max")
        axs[0, 1].plot(dates, avg_windspeed, label = "Avg")
        axs[0, 1].plot(dates, wind_gust, label = "Gust")
        axs[0, 1].set(ylabel = "Wind Speed (Mph)")
        axs[0, 1].set_title('Max, Average Windspeed and Wind Gust')
        axs[0, 1].legend()
       
       

        #axs[1, 0] will show trends in Temperature
        axs[1, 0].plot(dates, max_temps,label = "Max")
        axs[1, 0].plot(dates, min_temps, label = "Min")
        axs[1, 0].plot(dates, avg_temps, label = "Avg")
        axs[1, 0].set(ylabel = "Temperature (F)")
        axs[1, 0].set_title('Max, Min & Average Temperature')
        axs[1, 0].legend()

        #axs[1, 1] shows trends in Humidity
        axs[1, 1].plot(dates, max_humidity,label = "Max")
        axs[1, 1].plot(dates, min_humidity, label = "Min")
        axs[1, 1].plot(dates, avg_humidity, label = "Avg")
        axs[1, 1].set(ylabel = "Humidity (%)")
        axs[1, 1].set_title('Max, Min & Average Humidity')
        axs[1, 1].legend()

        #axs[0, 2] is a bar graph showing avg Rainfall
        axs[2, 0].bar(dates, precipitation)
        axs[2, 0].set(ylabel = "Rainfall (mm)")
        axs[2, 0].set_title('Average Rainfall')

        #axs[1, 2] is a bar graph showing Sun Hours
        axs[2, 1].bar(dates, sun_hours)
        axs[2, 1].set(ylabel = "Sun Hours")
        axs[2, 1].set_title('Sun Hours')

        #for ax in axs.flat:
            #ax.set(xlabel='Day')
        plt.xlabel("Day")
        plt.show()
        self.main_menu(self.start1,self.username1)

    def plot_month(self, x):
        date, max_temps, min_temps, avg_temps, max_humidity, min_humidity, avg_humidity, cloud_cover, max_windspeed, min_windspeed, avg_windspeed, wind_gust, max_pressure, min_pressure, avg_pressure, visibility, sun_hours, precipitation = x
        
        location = input("Enter Location >> ")
        year = input("Enter year >> ")

        C = len(date)
        B = list(range(1,C+1)) #creates xticks

        fig, axs = plt.subplots(2, 3)
        plt.setp(axs, xticks = B, xticklabels = date)
        fig.suptitle(f'Weather Trends for {location} in {year}')
        axs[0, 0].plot(B, max_pressure, label = "Max")
        axs[0, 0].plot(B, min_pressure, label = "Min")
        axs[0, 0].plot(B, avg_pressure, label = "Avg")
        axs[0, 0].set(ylabel = "Pressure (Hg)")
        axs[0, 0].set_title('Min, Max, Average Pressure (Hg)')
        axs[0, 0].legend()
        

        axs[0, 1].plot(B, max_windspeed,label = "Max")
        axs[0, 1].plot(B, avg_windspeed, label = "Avg")
        axs[0, 1].plot(B, wind_gust, label = "Gust")
        axs[0, 1].set(ylabel = "Wind Speed (Mph)")
        axs[0, 1].set_title('Max, Average Windspeed and Wind Gust')
        axs[0, 1].legend()

        axs[0, 2].bar(B, precipitation)
        axs[0, 2].set(ylabel = "Rainfall (mm)")
        axs[0, 2].set_title('Average Rainfall')
        

        axs[1, 0].plot(B, max_temps,label = "Max")
        axs[1, 0].plot(B, min_temps, label = "Min")
        axs[1, 0].plot(B, avg_temps, label = "Avg")
        axs[1, 0].set(ylabel = "Temperature (F)")
        axs[1, 0].set_title('Max, Min & Average Temperature')
        axs[1, 0].legend()

        axs[1, 1].plot(B, max_humidity,label = "Max")
        axs[1, 1].plot(B, min_humidity, label = "Min")
        axs[1, 1].plot(B, avg_humidity, label = "Avg")
        axs[1, 1].set(ylabel = "Humidity (%)")
        axs[1, 1].set_title('Max, Min & Average Humidity')
        axs[1, 1].legend()

        axs[1, 2].bar(B, sun_hours)
        axs[1, 2].set(ylabel = "Sun Hours")
        axs[1, 2].set_title('Sun Hours')

        for ax in axs.flat:
            ax.set(xlabel='Month')

        plt.show()
        self.main_menu(self.start1,self.username1)
    
    def plot_year(self, x):
        date, max_temps, min_temps, avg_temps, max_humidity, min_humidity, avg_humidity, cloud_cover, max_windspeed, min_windspeed, avg_windspeed, wind_gust, max_pressure, min_pressure, avg_pressure, visibility, sun_hours, precipitation = x
        location = input("Enter Location Name >> ")
        period = input("Enter Period >> ")

        C = len(date)
        B = list(range(1,C+1))
       
        fig, axs = plt.subplots(2, 3)
        plt.setp(axs, xticks = B, xticklabels = date)
        fig.suptitle(f'Weather Trends for {location} between {period}')
        axs[0, 0].plot(B, max_pressure, label = "Max")
        axs[0, 0].plot(B, min_pressure, label = "Min")
        axs[0, 0].plot(B, avg_pressure, label = "Avg")
        axs[0, 0].set(ylabel = "Pressure (Hg)")
        axs[0, 0].set_title('Min, Max, Average Pressure (Hg)')
        axs[0, 0].legend()
        

        axs[0, 1].plot(B, max_windspeed,label = "Max")
        axs[0, 1].plot(B, avg_windspeed, label = "Avg")
        axs[0, 1].plot(B, wind_gust, label = "Gust")
        axs[0, 1].set(ylabel = "Wind Speed (Mph)")
        axs[0, 1].set_title('Max, Average Windspeed and Wind Gust')
        axs[0, 1].legend()

        axs[0, 2].bar(B, precipitation)
        axs[0, 2].set(ylabel = "Rainfall (mm)")
        axs[0, 2].set_title('Average Rainfall')
        
        

        axs[1, 0].plot(B, max_temps,label = "Max")
        axs[1, 0].plot(B, min_temps, label = "Min")
        axs[1, 0].plot(B, avg_temps, label = "Avg")
        axs[1, 0].set(ylabel = "Temperature (F)")
        axs[1, 0].set_title('Max, Min & Average Temperature')
        axs[1, 0].legend()

        axs[1, 1].plot(B, max_humidity,label = "Max")
        axs[1, 1].plot(B, min_humidity, label = "Min")
        axs[1, 1].plot(B, avg_humidity, label = "Avg")
        axs[1, 1].set(ylabel = "Humidity (%)")
        axs[1, 1].set_title('Max, Min & Average Humidity')
        axs[1, 1].legend()

        axs[1, 2].bar(B, sun_hours)
        axs[1, 2].set(ylabel = "Sun Hours")
        axs[1, 2].set_title('Sun Hours')
        
        

        for ax in axs.flat:
            ax.set(xlabel='Year')
            


        plt.show()
        self.main_menu(self.start1,self.username1)
    
    def main_menu(self, start, username): #this block contains the two main menus to be used by the  users


        self.start1 = start

        def visuals():
            print("""\n
                        *********************************
                                DATA VISUALISATIONS
                        *********************************
                                [1] USE DAILY DATA
                                [2] USE MONTHLY DATA
                                [3] USE YEARLY DATA

                                [R] RETURN TO MENU
                        ---------------------------------
                    """)
            inpt = input(" >> ")
            if inpt == "1":
                self.plot_day(self.extract())

            elif(inpt == "2"):
                self.plot_month(self.extract())

            elif(inpt == "3"):
                self.plot_year(self.extract())

            elif(inpt.upper() == "R"):
                print("Are you sure you want to return to Main Menu ?")
                qsn = input("Yes(Y) or No (N) >> ")

                if qsn.upper() == "Y":
                    self.main_menu(self.start1,self.username1)
                else:
                    visuals()
            else:
                print("Invalid Input!")
                visuals()
    
        def admin_menu():   #this menu is only visible to the adminstrator who has more priviledges than the ordinary user
            today = date.today()

            d1 = today.strftime("%b-%d-%Y")
            t1 = strftime('%H:%M:%S %p')

            print()
            print("""\n
                        *********************************
                          """, d1," | ", t1, """
                        ---------------------------------
                                CLIMATE BUDDY v1.01
                        *********************************
                                CHOOSE OPERATION 
                        *********************************
                            [1] ADD USER
                            [2] DELETE USER
                            [3] GET USER INFORMATION
                            [4] EXTRACT FROM DAILY >> MONTHLY
                            [5] EXTRACT FROM MONTHLY >> YEARLY
                            [6] VISUALISATION AND ANALYSIS

                                [Q] QUIT

                        ---------------------------------   
                            logged in as >> """, start.getUser(username).getAccess(), """
                            """)
            userInput = input(" >>>>> ")    #used to get user choice

            if (userInput == "1"):
                name = input("Enter Full Name >> ")
                usern = input("Enter prefered username >> ").lower()
                password = getpass.getpass().lower()
                re_enter = getpass.getpass().lower()
                access = input("Enter Access level >> ").lower()

                if (password == re_enter):
                    acc = access
                    setter = Users(name, password, access)
                    setter.set_access(acc)
                    start.create_user(usern, setter)
                    print("User has been created.\nPlease keep your login credentials safe!")
                    admin_menu()
                else:
                    print("Passwords did not match !\nMake sure you have all the details and try again.")
                    admin_menu()

            elif (userInput == "2"):
                name = input("Enter Username >> ")
                if name in start.users:
                    print("Are you sure you want to delete user >>", name," from the system?")
                    ans = input("Yes (Y) or No (N) >> ")
                    if ans.upper() == "Y":
                        start.remove(name)
                        print("Record has been deleted!!")
                        admin_menu()
                    else:
                        print("Operation Aborted !!")
                        admin_menu()        
                else:
                    print("The user you want to delete does not exist!")
                    admin_menu()
            elif (userInput == "3"):
                userName = input("Enter Username >> ")
                if userName in start.users:
                    get = start.getUser(userName)
                    print("""\n
                            
                                    USER DETAILS FOR:
                        ------------------------------------
                            Full Name      | """,get.getuser(),"""
                            Username       | """,userName,"""
                            Password       | """,get.getpass(),"""
                            Access Level   | """,get.getAccess(),"""
                        ------------------------------------

                            """)
                    admin_menu()
                else:
                    print("User Not in the Database!")
                    admin_menu()
            elif (userInput == "4"):
                self.writecsv()

            elif (userInput == "5"):
                self.writecsv()

            elif (userInput == "6"):
                visuals()
                

            elif(userInput.upper() == "Q"):
                print("Are you sure you want to exit?")
                exitans = input("Yes (Y) or No (N) >> ")
                if (exitans.upper() == "Y"):
                    print("Thank you for using Climate Buddy v1.01.\nMake sure to check for updates!")
                    self.savejson(start)
                    exit()
                else:
                    print("Exit Procedure Aborted!")
                    admin_menu()
            else:
                print("Invalid Input !!")
                self.main_menu(self.start1,self.username1)

        def user_menu():    #this menu is for the ordinary users
            today = date.today()

            d1 = today.strftime("%b-%d-%Y")
            t1 = strftime('%H:%M:%S %p')
            print("""\n
                        *********************************
                            """, d1," | ", t1, """
                        ---------------------------------
                                CLIMATE BUDDY v1.01
                        *********************************
                                CHOOSE OPERATION 
                        *********************************
                            [1] EXTRACT DAILY >> MONTHLY
                            [2] EXTRACT MONTHLY >> YEARLY
                            [3] VISUALISATION & ANALYSIS

                                [Q] QUIT

                        ---------------------------------   
                            logged in as >> """,start.getUser(username).getAccess(),"""
                            """)
            userAns = input(" >>>> ")       #used to get user choice
            if (userAns == "1"):
                self.writecsv()

            elif(userAns == "2"):
                self.writecsv()
            elif(userAns == "3"):
                visuals()
                
            elif(userAns.upper() == "Q"):
                print("Are you sure you want to exit?")
                exitans = input("Yes (Y) or No (N) >> ")
                if (exitans.upper() == "Y"):
                    print("Thank you for using Climate Buddy v1.01.\nMake sure to check for updates soon!")
                    
                    exit()
                else:
                    print("Exit Procedure Aborted!")
                    user_menu()
            else:
                print("Invalid Input !!")
                self.main_menu(self.start1,self.username1)

        if start.getUser(username).getAccess() == "admin":  #validation check which differentiates ordinary user from admin user
            admin_menu()
        elif start.getUser(username).getAccess() == "user":
            user_menu()
    

class Climate:
    #Climate creates users from predefined template in Users and stores in a dict for manipulation
    users = {}
    def __init__(self, name):
        self.System = name

    def create_user(self, username, user):
        self.users[username] = user
    
    def remove(self, username):
        if username in self.users:
            del self.users[username]

    def getUser(self, username):
        return self.users[username]

    def getall(self):
        return self.users

class Users:
    #Users is a template that defines the structure of a user 
    def __init__ (self, username, password, access):
        
        self.username = username
        self.password = password
        self.access = access
 

    def getuser(self):
        return self.username
    
    def getpass(self):
        return self.password

    def set_access(self, x):
        self.level = x

    def getAccess(self):
        return self.access

def run():
    Climate_obj = Climate_Buddy() # climate_obj is an instance of Climate_Buddy which contains functions that operate on the data
    
    start = Climate_obj.loadjson() #start is a variable which stores value[climate object] returned by loadjson()
    username = Climate_obj.login(start)# username is a variable that stores username returned by login()
  
    Climate_obj.main_menu(start, username)# this code climate_obj calls main_menu()in Climate_Buddy using start & username as arguments which runs the whole program
   

run()



